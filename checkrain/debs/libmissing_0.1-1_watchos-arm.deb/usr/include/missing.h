#ifndef _MISSING_H
#define _MISSING_H
int system(char *command);
#endif
