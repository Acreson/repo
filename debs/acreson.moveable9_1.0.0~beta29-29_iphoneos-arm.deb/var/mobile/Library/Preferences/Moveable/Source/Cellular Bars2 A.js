(height, signalStrengthRaw, isTintBlack, extraOption, color)
{
	var lowerLimit = -130, upperLimit = -80;
	var range = Math.abs(lowerLimit - upperLimit);

	var percentage = 0;
	if (signalStrengthRaw <= lowerLimit) {
		percentage = 0;
	} else if (signalStrengthRaw >= upperLimit) {
		percentage = 1;
	} else {
		percentage = (signalStrengthRaw - lowerLimit) / range;
	}

	var
		canvas = document.createElement("canvas"),
		context = canvas.getContext("2d"),
		spacer = Math.round(height / 20.0),
		barWidth = Math.round(height / 7),
		barHeight = height / 2.0,
		mainColor = "rgb(" + color.join() + ")",
		secondColor = "rgba(" + color.join() + ",0.3)",
		canvasHeight = height,
		canvasWidth = Math.round(barWidth * 5 + 4 * spacer);

	canvas.width = canvasWidth;
	canvas.height = canvasHeight;

	var y = barHeight + (canvasHeight - barHeight) / 2;
	var y1 = (canvasHeight - barHeight) / 2;
	var y2 = barHeight + y1;
	fillWidth = Math.round(percentage * canvasHeight);

	context.save();
	context.beginPath();
	context.moveTo(0, y2);
	context.lineTo(canvasWidth, y2);
	context.lineTo(canvasWidth, y1);
	context.fillStyle = secondColor;
	context.clip();
	for (var i = 0; i < 5; i++) {
		context.rect((i+1) * barWidth + i * spacer, y1, spacer, barHeight);
		context.fillRect(i * barWidth + i * spacer, y1, barWidth, barHeight);
	}
	context.clip();
	context.fillStyle = mainColor;
	context.fillRect(0, y1, fillWidth, barHeight);

	return canvas.toDataURL("image/png");
}
