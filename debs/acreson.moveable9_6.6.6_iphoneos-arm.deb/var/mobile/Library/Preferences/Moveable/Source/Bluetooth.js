(height, percentage, isTintBlack, extraOption, color)
{
	var
		canvas = document.createElement("canvas"),
		context = canvas.getContext("2d"),
		barWidth = 0.4 * height,
		barHeight = 0.675 * height,
		lineWidth = height / 20,
		mainColor = "rgb(" + color.join() + ")",
		secondColor = "rgba(" + color.join() + ",0.1)",
		canvasHeight = height,
		canvasWidth = Math.round(barWidth + height / 5.0);

	canvas.width = canvasWidth;
	canvas.height = canvasHeight;
	yOffset = Math.round(canvasWidth - barWidth) / 2;

	// context.lineWidth = lineWidth;
	// context.strokeStyle = mainColor;
	// context.beginPath();
	// context.moveTo(0, 13);
	// context.lineTo(barWidth - 3, 26);
	// context.lineTo(7, 32);
	// context.lineTo(7, 9);
	// context.lineTo(barWidth - 3, 15);
	// context.lineTo(0, 27);
	// context.stroke();
	
	// y1 = 0.325 * height;
	// y2 = 0.675 * height;
	// cx = canvasWidth / 2;
	// radius = cx;

	// context.fillStyle = secondColor;
	// context.beginPath();
	// context.arc(cx, y2, radius, 0, 1 * Math.PI);
	// context.fill();

	// context.fillRect(0, y1, canvasWidth, y2 - y1);

	// context.beginPath();
	// context.arc(cx, y1, radius, 1 * Math.PI, 0);
	// context.fill();

	context.lineWidth = lineWidth;
	context.strokeStyle = mainColor;
	context.beginPath();
	context.moveTo(yOffset + 0, 0.325 * height);
	context.lineTo(yOffset + 0.325 * height, 0.65 * height);
	context.lineTo(yOffset + 0.175 * height, 0.8 * height);
	context.lineTo(yOffset + 0.175 * height, 0.225 * height);
	context.lineTo(yOffset + 0.325 * height, 0.375 * height);
	context.lineTo(yOffset + 0, 0.675 * height);
	context.stroke();

	return canvas.toDataURL("image/png");
}
